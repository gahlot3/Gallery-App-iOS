//
//  AuthSignInSignUpVM.swift
//  Gallery
//
//  Created by Emizen on 23/09/25.
//

import Foundation
import GoogleSignIn
import UIKit
import SwiftUI
internal import Combine
import SwiftData

class AuthSignInSignUpVM: ObservableObject {
    let objectWillChange = ObservableObjectPublisher()
    @Published var isSignedIn: Bool = false
    @Published var user: User? = nil
    private var modelContext: ModelContext?

    func setModelContext(_ context: ModelContext) {
        self.modelContext = context
        checkIfUserSignedIn()
    }

    func handleGoogleSignIn() {
        guard let rootViewController = UIApplication.shared.windows.first?.rootViewController else {
            print("No root view controller found")
            return
        }
        GIDSignIn.sharedInstance.signIn(
            withPresenting: rootViewController
        ) { [weak self] signInResult, error in
            if let error = error {
                print("Google Sign-In failed: \(error.localizedDescription)")
                return
            }
            guard let user = signInResult?.user else {
                print("Error : 1223 - Model context is nil")
                return }
            let email = user.profile?.email ?? ""
            let name = user.profile?.name ?? ""
            let id = user.userID ?? UUID().uuidString
            let profileImageURL = user.profile?.imageURL(withDimension: 200)?.absoluteString
            let newUser = User(id: id, name: name, email: email, profileImageURL: profileImageURL)
            print("Login User Data: \(newUser.name), \(newUser.email)")
            DispatchQueue.main.async {
                self?.saveUser(newUser)
            }
        }
    }

    private func saveUser(_ user: User) {
        self.isSignedIn = true
        guard let context = modelContext else {
            print("Error : 122 - Model context is nil")
            return }
        context.insert(user)
        self.user = user
       
    }

    func checkIfUserSignedIn() {
        guard let context = modelContext else {
            print("Error : 12442 - Model context is nil")
            return }
        let descriptor = FetchDescriptor<User>()
        if let existingUser = try? context.fetch(descriptor).first {
            self.user = existingUser
            self.isSignedIn = true
        } else {
            self.user = nil
            self.isSignedIn = false
        }
    }

    func logout() {
        // Remove user from SwiftData
        guard let context = modelContext else {
            print("Error : 122 - Model context fdsfdsf is nil")
            return }
        let descriptor = FetchDescriptor<User>()
        if let users = try? context.fetch(descriptor) {
            for user in users {
                context.delete(user)
            }
        }
        self.user = nil
        self.isSignedIn = false
    }
}
