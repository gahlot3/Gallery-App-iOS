import SwiftUI
import SwiftData

struct HomeView: View {
    @Environment(\.modelContext) private var modelContext
    @State private var images: [GalleryImage] = []
    @State private var page: Int = 1
    @State private var isLoading = false
    @State private var showProfile = false
    let user: User?
    
    var body: some View {
        NavigationView {
            VStack {
                if images.isEmpty && isLoading {
                    ProgressView("Loading images...")
                } else {
                    ScrollView {
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 120), spacing: 12)], spacing: 12) {
                            ForEach(images, id: \.id) { image in
                                GalleryImageView(galleryImage: image)
                                    .frame(height: 180)
                            }
                        }
                        .padding()
                        if !isLoading {
                            Button("Load More") {
                                loadImages(page: page + 1)
                            }
                            .padding()
                        }
                    }
                }
            }
            .navigationTitle("Wallpapers")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showProfile = true }) {
                        Image(systemName: "person.crop.circle")
                    }
                }
            }
            .sheet(isPresented: $showProfile) {
                ProfileView(user: user) {
                    // On logout, pop to login
                    NotificationCenter.default.post(name: .logout, object: nil)
                }
            }
            .onAppear {
                if images.isEmpty { loadImages(page: 1) }
            }
        }
    }
    
    private func loadImages(page: Int) {
        isLoading = true
        ImageService.shared.fetchImages(page: page, context: modelContext) { newImages in
            if page == 1 {
                images = newImages
            } else {
                images.append(contentsOf: newImages)
            }
            self.page = page
            isLoading = false
        }
    }
}

struct GalleryImageView: View {
    let galleryImage: GalleryImage
    @State private var uiImage: UIImage? = nil
    @State private var isLoading = false
    
    var body: some View {
        ZStack {
            if let uiImage = uiImage {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFill()
                    .clipped()
            } else if isLoading {
                ProgressView()
            } else {
                Color.gray.opacity(0.2)
                    .onAppear(perform: loadImage)
            }
        }
        .cornerRadius(10)
        .shadow(radius: 2)
    }
    
    private func loadImage() {
        isLoading = true
        if let localPath = galleryImage.localPath, let image = UIImage(contentsOfFile: localPath) {
            self.uiImage = image
            self.isLoading = false
        } else {
            ImageService.shared.downloadImage(galleryImage) { path in
                if let path = path, let image = UIImage(contentsOfFile: path) {
                    self.uiImage = image
                }
                self.isLoading = false
            }
        }
    }
}

extension Notification.Name {
    static let logout = Notification.Name("LogoutNotification")
}
