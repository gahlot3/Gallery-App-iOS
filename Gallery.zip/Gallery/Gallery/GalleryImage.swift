import Foundation
import SwiftData

@Model
final class GalleryImage: Identifiable, Hashable {
    var id: String
    var url: String
    var localPath: String?
    var page: Int
    var createdAt: Date
    
    init(id: String, url: String, localPath: String? = nil, page: Int, createdAt: Date = Date()) {
        self.id = id
        self.url = url
        self.localPath = localPath
        self.page = page
        self.createdAt = createdAt
    }
    
    static func == (lhs: GalleryImage, rhs: GalleryImage) -> Bool {
        lhs.id == rhs.id
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}
