import Foundation
import SwiftData
import UIKit

class ImageService : NSObject {
    
    static let shared = ImageService()
    private let session = URLSession.shared
    private let imagesPerPage = 10
    
    // Example Unsplash API (replace with your own key for production)
    private let apiURL = "https://picsum.photos/v2/list"
    
    func fetchImages(page: Int, context: ModelContext, completion: @escaping ([GalleryImage]) -> Void) {
        // Try to load from SwiftData first
        let descriptor = FetchDescriptor<GalleryImage>(predicate: #Predicate { $0.page == page })
        if let cached = try? context.fetch(descriptor), !cached.isEmpty {
            completion(cached)
            return
        }
        // Otherwise, fetch from API
        guard let url = URL(string: apiURL) else {
            completion([])
            return
        }
        session.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                DispatchQueue.main.async { completion([]) }
                return
            }
            // Parse Picsum API response
            guard let json = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else {
                DispatchQueue.main.async { completion([]) }
                return
            }
            var images: [GalleryImage] = []
            for item in json {
                if let id = item["id"] as? String,
                   let url = item["download_url"] as? String {
                    let image = GalleryImage(id: id, url: url, page: page)
                    context.insert(image)
                    images.append(image)
                }
            }
            DispatchQueue.main.async { completion(images) }
        }.resume()
    }

    func downloadImage(_ galleryImage: GalleryImage, completion: @escaping (String?) -> Void) {
        guard let url = URL(string: galleryImage.url) else {
            completion(nil)
            return
        }
        session.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                completion(nil)
                return
            }
            // Save to documents directory
            let filename = "gallery_\(galleryImage.id).jpg"
            let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent(filename)
            do {
                try data.write(to: fileURL)
                completion(fileURL.path)
            } catch {
                completion(nil)
            }
        }.resume()
    }
}
