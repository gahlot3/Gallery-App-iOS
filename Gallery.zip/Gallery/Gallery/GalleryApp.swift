//
//  ContentView.swift
//  Gallery
//
//  Created by Emizen on 23/09/25.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    @EnvironmentObject var authVM: AuthSignInSignUpVM

    var body: some View {
        Group {
            if authVM.isSignedIn, let user = authVM.user {
                HomeView(user: user)
                    
            } else {
                LoginView()
            }
        }
    }
}



struct LoginView: View {
    @EnvironmentObject var authVM: AuthSignInSignUpVM

    var body: some View {
        VStack{
            Button {
                authVM.handleGoogleSignIn()
            } label: {
                Text("Login With Google")
                    .font(.title2)
                    .bold()
                    .frame(maxWidth: .infinity, minHeight: 50)
            }
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
            .padding(.horizontal, 20)
        }
    }
}
