import SwiftUI

struct ProfileView: View {
    let user: User?
    var onLogout: () -> Void
    
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                if let user = user {
                    if let urlString = user.profileImageURL, let url = URL(string: urlString) {
                        AsyncImage(url: url) { image in
                            image.resizable().aspectRatio(contentMode: .fill)
                        } placeholder: {
                            ProgressView()
                        }
                        .frame(width: 100, height: 100)
                        .clipShape(Circle())
                    } else {
                        Image(systemName: "person.crop.circle.fill")
                            .resizable()
                            .frame(width: 100, height: 100)
                            .foregroundColor(.gray)
                    }
                    Text(user.name)
                        .font(.title2)
                        .bold()
                    Text(user.email)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                Spacer()
                Button(action: onLogout) {
                    Text("Logout")
                        .foregroundColor(.red)
                        .bold()
                        .frame(maxWidth: .infinity, minHeight: 44)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                }
                .padding(.horizontal)
            }
            .padding()
            .navigationTitle("Profile")
        }
    }
}
