import Foundation
import SwiftData

@Model
final class User {
    var id: String
    var name: String
    var email: String
    var profileImageURL: String?
    var lastSignIn: Date
    
    init(id: String, name: String, email: String, profileImageURL: String? = nil, lastSignIn: Date = Date()) {
        self.id = id
        self.name = name
        self.email = email
        self.profileImageURL = profileImageURL
        self.lastSignIn = lastSignIn
    }
}
